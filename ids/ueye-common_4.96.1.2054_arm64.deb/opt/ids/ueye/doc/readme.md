# IDS Software Suite 4.96.1.2054 for Linux

## Contents

**[System requirements](#system-requirements)** \
**[Notes on Linux Embedded](#notes-on-linux-embedded)** \
**[Notes on older camera models](#notes-on-older-camera-models)** \
**[Installation](#installation)** \
**[First start](#first-start)** \
**[Known issues](#known-issues)** \
**[List of contained files and dependencies](#list-of-contained-files-and-dependencies)** \
**[Uninstallation](#uninstallation)** \
**[Contact](#contact)**

## System requirements

For operating the uEye cameras, the following system requirements must be met:

|                  | USB 3.1/USB 3.0 camera                                                                 | USB 2.0 camera                                            | GigE camera                       |
|------------------|----------------------------------------------------------------------------------------|-----------------------------------------------------------|-----------------------------------|
| Interface        | USB 3.0 port (Super Speed)                                                             | USB 2.0 port (High Speed 480 Mbps, "Full Powered" 500 mA) | Gigabit Ethernet port (1000 Mbps) |
| CPU              | Intel i5 or better                                                                     | Intel i3 or better                                        | Intel i3 or better                |
| Memory           | min. 2 GB                                                                              | min. 2 GB                                                 | min. 2 GB                         |
| Disk space       | min. 500 MB                                                                            | min. 500 MB                                               | min. 500 MB                       |
| Operating system | **Linux > Kernel 3.4 (32/64-bit)**<br />For UI-3013XC: Linux ≥ Kernel 3.13 (32/64-bit) | Linux > Kernel 2.6 (32/64-bit)                            | Linux > Kernel 2.6 (32/64-bit)    |

Depending on the sensor model, the camera performance may be limited with the minimum system requirements.

### Compatibility list

The Linux operating system is one of the most widely ported, running on a huge amount of architectures and provided
over many distributions. Although we are trying to be compatible among the whole range of kernel versions and
distributions, there is no guarantee that the IDS Software Suite is working on a specific untested combination.

Below is a list of successfully tested distributions for the current IDS Software Suite:

- Debian 11.3 (bullseye)
- Debian 10.12 (buster)
- Debian 9.13 (stretch)
- Ubuntu 22.04 LTS (jammy)
- Ubuntu 20.04 LTS (focal)

### Linux Embedded

IDS offers camera drivers for hard float systems. Depending on the sensor model, the camera performance may be
limited by the embedded board. Below is a list of successfully tested platforms for the current IDS Software Suite.

| ARMv8 64-bit      | ARMv7 Cortex/ARMv8 32-bit      |
|-------------------|--------------------------------|
| Nvidia Jetson TX2 | Odroid XU4<br />Raspberry Pi 4 |

## Notes on Linux Embedded

### Hardware acceleration
IDS offers the IDS Software Suite for different ARM architectures with hard float (hf).

### Floating-Point-Unit
Many current ARM embedded boards and devices have an integrated hardware support for floating-point operations (FPU)
with the consequence of a higher performance in applications with various operations like image calculation,
transformations, exponential or trigonometric calculations with floating point arithmetic.
In the ARM environment VFP means "Vector Floating Point Architecture".

In contrast, soft float emulates an FPU in software. Corresponding operations run much slower than with hardware support
because to a higher CPU load.

### Hard float or soft float?
The following information is related to the GNU/Linux system that is installed on the embedded board.

### Querying the CPU info
If the used CPU features this hardware support, can be requested via the CPU information. The verification will show
entries in the features line of /proc/cpuinfo or in the VFP support message, logged out while the kernel boots.

```bash
pi@raspberrypi:~ $ cat /proc/cpuinfo
processor : 0
model name : ARMv7 Processor rev 4 (v7l)
BogoMIPS : 38.40
Features : half thumb fastmult vfp edsp neon vfpv3 tls vfpv4 idiva idivt vfpd32
lpae evtstrm crc32
CPU implementer : 0x41
CPU architecture: 7
CPU variant : 0x0
CPU part : 0xd03
CPU revision : 4
...
```

### What libraries are used?
What libraries are used by basic applications? For this purpose, a standard application like e.g. "ls" can be examined. The command ldd shows what libraries are linked.

```bash
pi@raspberrypi:~ $ ldd /bin/ls
linux-vdso.so.1 (0x7eec3000)
/usr/lib/arm-linux-gnueabihf/libarmmem.so (0x76ef7000)
libselinux.so.1 => /lib/arm-linux-gnueabihf/libselinux.so.1 (0x76eb7000)
libacl.so.1 => /lib/arm-linux-gnueabihf/libacl.so.1 (0x76ea0000)
libc.so.6 => /lib/arm-linux-gnueabihf/libc.so.6 (0x76d5f000)
/lib/ld-linux-armhf.so.3 (0x54af6000)
libpcre.so.3 => /lib/arm-linux-gnueabihf/libpcre.so.3 (0x76cec000)
libdl.so.2 => /lib/arm-linux-gnueabihf/libdl.so.2 (0x76cd9000)
libattr.so.1 => /lib/arm-linux-gnueabihf/libattr.so.1 (0x76cc3000)
libpthread.so.0 => /lib/arm-linux-gnueabihf/libpthread.so.0 (0x76c9b000)
```

Here, you see that the hard float libraries in the directory /lib/arm-linux-gnueabihf are used. That indicates a system with hard float support.

### Detailed information about a library or an application
Using the readelf tool shows more detailed information very easy. The presence of the file attribute 'Tag_ABI_VFP_args' for example shows the usage of the VFP registers.

For the check, choose the standard "C" library libc.so.6.

```bash
pi@raspberrypi:~ $ sudo readelf -A /lib/arm-linux-gnueabihf/libc.so.6
Attribute Section: aeabi
File Attributes
Tag_CPU_name: "6"
Tag_CPU_arch: v6
Tag_ARM_ISA_use: Yes
Tag_THUMB_ISA_use: Thumb-1
Tag_FP_arch: VFPv2
Tag_ABI_PCS_wchar_t: 4
Tag_ABI_FP_rounding: Needed
Tag_ABI_FP_denormal: Needed
Tag_ABI_FP_exceptions: Needed
Tag_ABI_FP_number_model: IEEE 754
Tag_ABI_align_needed: 8-byte
Tag_ABI_enum_size: int
Tag_ABI_HardFP_use: SP and DP
Tag_ABI_VFP_args: VFP registers
Tag_CPU_unaligned_access: v6
```

When the line with **Tag_ABI_VFP_args** is not present, it is a soft float system.

Tip: If you do not know the directory of the libc.so.6 file, you can search for it using
```bash
$> sudo find / -name libc.so.6
```

## Configuration notes

- According to the IDS Software Suite version, the Linux system has to support a minimum required version of the
GNU C Library (GLIBC, libc.so.6) and the GNU C++ Library (GLIBCXX, libstdc++.so.6):
  - libc: minimum version 2.22
  - libstdc++: minimum version 3.4.21
- POSIX threads library (POSIX threads enabled libc)
- bash (Bourne again shell) or sh to run the script
- libcap v2
- libomp (libomp.so.5)
- libatomic (libatomic.so.1)
- udev min. v105
- libusb with [hotplug support](http://libusb.sourceforge.net/api-1.0/group__libusb__hotplug.html)
- libpng (libpng16.so.16) for support of saving images in PNG format
- libjpeg (libjpeg.so.8 or libjpeg.so.62) for support of saving images in JPEG format and JPEG mode of XS
- OpenGL graphics functions
  - For OpenGL, version 1.4 or higher must be installed.
- If you want to have a graphical environment by using tools like the IDS Camera Manager or the uEye Demo application,
you need to install the Qt framework (min. version Qt 5.5)
- Installation of IDS Software Suite 4.95 (or higher) will break USB driver installations prior to 4.95

## Notes on older camera models

Former versions of the IDS Software Suite can be downloaded in the software archive under
https://en.ids-imaging.com/downloads.html.

### uEye CCD cameras
All uEye CCD cameras are supported by driver version 4.96.1 for the last time. For specific model numbers see the 
according [pdf](https://en.ids-imaging.com/files/downloads/support/product-discontinuations/Discontinuation_Letter_Sony_CCD_20150324.pdf).

### uEye cameras with CMV2000/CMV4000 sensor models
The camera models UI-336xCP, UI-536xCP, UI-337xCP, UI-337xSE, UI-537xCP are supported by driver version 4.96.1 for
the last time. For specific part numbers see the according 
[337x-537x-pdf](https://en.ids-imaging.com/files/downloads/support/product-discontinuations/PDN_IDS_2022-03-08_uEye_UI-337x_UI-537x.pdf) 
and [336x-536x-pdf](https://en.ids-imaging.com/files/downloads/support/product-discontinuations/PDN_IDS_2022-03-08_uEye_UI-337x_UI-537x.pdf).

### GigE uEye ACP, USB3 uEye ACP
All GigE uEye ACP (UI-5xxxACP) and all USB3 uEye ACP (UI-3xxxACP) are supported by driver version 4.96.1 for the last
time. For specific part numbers see the according 
[pdf](https://en.ids-imaging.com/files/downloads/support/product-discontinuations/PDN_IDS_2022-03-08_uEye_ACP_UI.pdf).

### uEye cameras based on onsemi sensors
The following camera models are supported by driver version 4.96.1 for the last time:

#### UI-122xLE and UI-122xSE (USB2), UI-322xCP (USB3), UI-522xCP, UI-522xSE and UI-522xRE PoE (GigE)
For specific part numbers see the according 
[pdf](https://en.ids-imaging.com/files/downloads/support/product-discontinuations/PDN_IDS_2021-02-25_UI-122x_UI-322x_UI-522x.pdf).

#### UI-146xLE and UI-146xSE (USB2), UI-546xSE and UI-546xRE PoE (GigE)
For specific part numbers see the according 
[pdf](https://en.ids-imaging.com/files/downloads/support/product-discontinuations/PDN_IDS_2021-02-26_UI-146x_UI-546x.pdf).

#### UI-155xLE and UI-155xSE (USB2), UI-555xSE and UI-555xRE PoE (GigE)
For specific part numbers see the according 
[pdf](https://en.ids-imaging.com/files/downloads/support/product-discontinuations/PDN_IDS_2020-02-26_UI-155x_UI-555x_UV-155x.pdf).

#### UI-164xLE and UI-164xSE (USB2), UI-564xSE and UI-564xRE PoE (GigE)
For specific part numbers see the according 
[pdf](https://de.ids-imaging.com/files/downloads/support/product-discontinuations/PDN_IDS_2021-02-26_UI-164x_UI-564x.pdf).

### UI-1005-XS
The camera model UI-1005-XS is supported by driver version 4.96.1 for the last time.

### UI-3160CP-M-GL Rev.2, UI-3180CP-M-GL Rev.2
The UI-3160CP-M-GL Rev.2 and UI-3180CP-M-GL Rev.2 camera model are supported by driver version 4.96.1 for the last time.
The camera models UI-3160CP-M-GL Rev.2.1 and UI-3180CP-M-GL Rev.2.1 are not affected. See also the according 
[pdf](https://de.ids-imaging.com/files/downloads/support/product-changes/PCN_2018-02-08_Python2000-5000_v1.1.pdf).

### UI-3013XC
The UI-3013XC camera model is supported by driver version 4.92 for the last time.

### UI-112xSE, UI-512xSE, and XS
The models UI-112xSE, UI-512xSE, and XS are supported by driver version 4.91 for the last time.

### UI-1008XS
The UI-1008XS camera model is supported by driver version 4.81 for the last time.

### GigE uEye RE
The GigE uEye RE camera family is supported by driver version 4.80 for the last time. The GigE uEye RE PoE camera
family is not affected by this.

### USB 2 uEye RE
The USBE uEye RE camera family is supported by driver version 4.80 for the last time.

### USB 2 uEye ME
The USB uEye ME camera family is supported by driver version 4.40 for the last time.

### GigE uEye HE
The GigE uEye HE camera family is supported by driver version 3.82 for the last time.

### USB uEye SE
The models UI-121xSE, UI-141xSE, UI-144xSE, UI-145xSE, and UI-154xSE-C have been discontinued and will not be tested
from driver version 3.80 on. IDS Imaging Development Systems GmbH therefore cannot guarantee that these models will
provide full functionality with new driver versions and operate without problems.

### uEye memory board USB uEye SE/USB uEye RE
The optional memory board of the USB uEye SE and USB uEye RE camera series has been discontinued.
The functions required to operate the memory board are supported up to and including driver version 3.25.

### Older USB 2 uEye CMOS cameras
All USB CMOS cameras with USB board revision < 2.1 are not supported by driver versions > 3.10.
How can you check whether your camera is affected?

Check the serial number of your camera. If it is less than 400 26 27000, your camera will not be
compatible with driver versions > 3.10.

If your camera is not compatible with driver versions > 3.10, you can of course continue to use your present driver
(up to version 2.40).

## Installation

NOTICE! Prior to installing IDS Software Suite 4.95, previous versions of IDS Software Suite must be uninstalled!

**You must be root to install the software.**

- If a firewall is active on your system, ensure that UDP ports 50000 to 50003 are not filtered if you installed the
GigE uEye variant.
- It is recommended to use a system-wide, fully static interface configuration for the network interfaces that GigE
uEye cameras are connected to.

There are different ways for installation: either as Debian packet or as archive (run or .tgz/tar.gz).

### Debian packages (download via IDS website)

Installation order of the Debian packages: You have to install the "ueye-api" package first and then the "ueye-common"
package, as all other uEye packages depend on it.

| Using "sudo"                                                                                                                                                                                                                                                                                                      |
|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Install dependencies                                                                                                                                                                                                                                                                                              |
 | ```[user@pc]$ sudo apt-get install <package name>```                                                                                                                                                                                                                                                              |
| Package: **ueye-api**<br />Depends: debconf, libc6 (minimum version 2.22), libomp5 (minimum version 3.7) [!armhf], libomp5 (minimum version 5.0) [armhf], libomp5-7 [armhf], libomp5-8 [armhf], libatomic1 (minimum version 5.4)<br />Suggests: ueye-driver-eth, ueye-driver-usb                                  |
| Package: **ueye-common**<br />Depends: ueye-api<br />Suggests: ueye-driver-eth, ueye-driver-usb                                                                                                                                                                                                                   |
| Package: **ueye-demos**<br />Depends: ueye-common, libc6 (minimum version 2.22), libstdc++6 (minimum version 3.4.21), libqt5widgets5 (minimum version 5.5), libqt5gui5 (minimum version 5.5), libqt5opengl5 (minimum version 5.5), libqt5concurrent5 (minimum version 5.5)<br />Suggests: cmake, build-essential  |
| Package: **ueye-dev**<br />Depends: ueye-common<br />Recommends: build-essential<br />Suggests: cmake                                                                                                                                                                                                             |
| Package: **ueye-driver-eth**<br />Depends: ueye-common, libc6 (minimum version 2.22), libcap2<br />Suggests: ueye-tools-cli, ueye-tools-qt5                                                                                                                                                                       |
| Package: **ueye-driver-usb**<br />Depends: ueye-common, libc6 (minimum version 2.22), libcap2, libusb-1.0-0<br />Suggests: ueye-tools-cli, ueye-tools-qt5                                                                                                                                                         |
| Package: **ueye-manual-de**                                                                                                                                                                                                                                                                                       |
| Package: **ueye-manual-en**                                                                                                                                                                                                                                                                                       |
| Package: **ueye-tools-cli**<br />Depends: ueye-common, libc6 (minimum version 2.22), libstdc++6 (minimum version 3.4.21)                                                                                                                                                                                          |
| Package: **ueye-tools-qt5**<br />Depends: ueye-common, libc6 (minimum version 2.22), libstdc++6 (minimum version 3.4.21), libqt5widgets5 (minimum version 5.5), libqt5gui5 (minimum version 5.5), libqt5network5 (minimum version 5.5), libqt5concurrent5 (minimum version 5.5), libqt5xml5 (minimum version 5.5) |
| Package: **ueye-interfaces-halcon**<br />Depends: libc6 (minimum version 2.22)                                                                                                                                                                                                                                    |
| Install he package via **dpkg**                                                                                                                                                                                                                                                                                   |
| ```[user@pc]$ sudo dpkg -i ids_ueye_<version>_<arch>.deb```                                                                                                                                                                                                                                                       |

### Debian packages (Debian repository server)

1. First of all, you must add the uEye repository to the **sources.list** file. Therefore, make a backup copy of the
file:<br />
```[user@pc]$ sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak```
2. Add the uEye repository and your IDS webstore login:
Debian:<br />
```[user@pc]$ sudo sh -c 'echo "deb https://<IDS webstore user name>:<IDS webstore password>@repo.ids-imaging.com/debian <distribution, see Compatibility list> main" >> /etc/apt/sources.list'```<br />
Ubuntu:<br />
```[user@pc]$ sudo sh -c 'echo "deb https://<IDS webstore user name>:<IDS webstore password>@repo.ids-imaging.com/ubuntu <distribution, see Compatibility list> main" >> /etc/apt/sources.list'```
3. Import the public key for the uEye repository:<br />
```[user@pc]$ sudo bash -c 'wget --http-user=<IDS webstore user name> --http-password=<IDS webstore password> -O - https://repo.ids-imaging.com/gpg.key | apt-key add -'```
4. In case you use a proxy server, use the following command:<br />
```[user@pc]$ sudo bash -c 'wget -e use_proxy=yes -e https_proxy=[proxy-ip-adress:proxy-port] --http-user=<IDS webstore user name> --http-password=<IDS webstore password> -O - https://repo.ids-imaging.com/gpg.key | apt-key add -'```
5. Now install the uEye packages with:<br />
```[user@pc]$ sudo apt-get update && sudo apt-get install ueye```<br />
If you want to install only certain parts, use "apt-cache" to show the available sources:<br />
```apt-cache search ueye```

Now the package manager installs the IDS Software Suite and its dependencies e.g. Qt 5.

### Archive

Before you start using the archive, make sure you have all required libraries installed:

- Qt: minimum version 5.5 (QtCore, QtGui, QtWidgets)
  - For uEye Demo: libQt5Concurrent.so.5, libQt5OpenGL.so.5
  - For uEye Hotpixel Editor: libQt5XML.so.5
- libc6: minimum version 2.22
  - For ARM: libc6: minimum version 2.24
- libstdc++: minimum version 4.9
  - For ARM: libstdc++: minimum version 6.3
- libusb

### Using the "run" script
1. Copy the setup file into a directory on the hard disk (you need write access to decompress).
2. Go to the directory you copied the files into and run the setup program script by typing (replace "version/arch" with the current identifiers of the installer file)

   ```$> sudo sh ./ueye-<version>_<arch>.run```

3. If any problems occurred, the known issues section below or the generated report file (./ids_ueye_YYYYMMDDhhmmss_PID.log) may include a hint to solve them (see installer output). If not, contact your local distributors support and submit the report file.

### Using the TAR archive

1. Copy the TAR archive into your home directory on the target system.
2. Unpack the archive with the tar program on the target system:

   ```tar xvf ueye_<version>_<arch>.tar```

3. Execute the setup script:

   ```./[extract-dir]/ueyesetup -i all```

Further information on installation options can be queried using:

```bash
./ueyesetup --help
./ueyesetup --longhelp
```

### Installed file structure

The created files will be installed in following directories (if you have not uninstalled the USB or GigE package):

|                                            |                                          |                                                                                                                                                                                                                                                                                                                                           |
|:-------------------------------------------|:-----------------------------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| /opt/ids/ueye/lib/libueye_api.so.[version] | uEye shared library                      | After ldconfig has finished, a symbolic link libueye_api.so should exist to provide linkage against libueye_api.so. Note that only the version for the current target architecture will be installed, e.g. the 32-bit library will only be installed on a 32-bit system and the 64-bit library will only be installed on a 64-bit system. |
| /opt/ids/ueye/include/ueye.h               | Development header file                  |                                                                                                                                                                                                                                                                                                                                           |
| /opt/ids/ueye/bin/ueyeethd                 | GigE uEye daemon binaries                | Configuration files are located under /etc/ids/...                                                                                                                                                                                                                                                                                        |
| /opt/ids/ueye/bin/ueyeusbd                 | USB uEye daemon binaries                 | Configuration files are located under /etc/ids/...                                                                                                                                                                                                                                                                                        |
| /opt/ids/ueye/licenses                     | Third party licenses and copyrights      |                                                                                                                                                                                                                                                                                                                                           |
| /opt/ids/ueye/firmware                     | Firmware binaries                        | Firmware binaries for USB 2, USB 3 and GigE cameras                                                                                                                                                                                                                                                                                       |
| /etc/init.d/ueyeethdrc                     | GigE uEye daemon runlevel control script | Is only installed if systemd is not available on your system                                                                                                                                                                                                                                                                              |
| /etc/init.d/ueyeusbdrc                     | USB uEye daemon runlevel control script  | Is only installed if systemd is not available on your system                                                                                                                                                                                                                                                                              |
| /lib/systemd/system/ueyeethdrc.service     | GigE uEye daemon service file            |                                                                                                                                                                                                                                                                                                                                           |
| /lib/systemd/system/ueyeusbdrc.service     | USB uEye daemon service file             |                                                                                                                                                                                                                                                                                                                                           |
| /opt/ids/ueye/src/ids/ueyedemo             | IDS demo sources                         |                                                                                                                                                                                                                                                                                                                                           |
| /opt/ids/ueye/doc/readme.md                | IDS Software Suite readme                |                                                                                                                                                                                                                                                                                                                                           |
| /opt/ids/ueye/manual                       | IDS Software Suite user manual           |                                                                                                                                                                                                                                                                                                                                           |

Additionally, the installer provides the following tools - unless not indicated otherwise, the tools will be installed
to /opt/ids/ueye/bin:

|                    |                                                                                     |
|:-------------------|:------------------------------------------------------------------------------------|
| ueyesetid	         | Camera ID configuration tool                                                        |
| ueyesetip	         | Camera IP address configuration tool                                                |
| idscameramanager   | IDS Camera Manager                                                                  |
| ueyedemo           | Demo application                                                                    |
| ueyehotpixeleditor | uEye Hotpixel Editor                                                                |
| ueyereport         | Report generator tool                                                               |
| ueyesetup          | IDS SDK setup tool<br />For installing/uninstalling the self-extracting tar archive |

#### Runtime directories

|            |                          |
|:-----------|:-------------------------|
| /run/ueyed | uEye runtime files       |
| /dev/shm   | uEye shared memory files |

#### Configuration directories

|               |                          |
|:--------------|:-------------------------|
| ~/.ueyeconf   | User configuration files |
| /etc/ids/ueye | uEye configuration files |

### User/group
The installer will create a system group 'ueye' and a system user 'ueyed' to run the daemon with. Currently there are no
access control restrictions, but be aware that this might change in the future.

## First start

**Note:** It is recommended to use systemd for controlling the daemons. Do not mix calls of systemd and init.d!

1. After installation, you may start the uEye daemons separately with systemd by typing:

   ```
   $> sudo systemctl start ueyeethdrc
   $> sudo systemctl start ueyeusbdrc
   ```

   If your system does not support systemd yet, you can use the following commands:
   ```
    $> sudo /etc/init.d/ueyeethdrc start
    $> sudo /etc/init.d/ueyeusbdrc start
   ```
   Before you stop the uEye daemons, make sure that there are no connections to it:
   ```
    $> sudo systemctl stop ueyeethdrc
    $> sudo systemctl stop ueyeusbdrc
   ```
   Or without systemd:
   ```
   $> sudo /etc/init.d/ueyeethdrc stop
   $> sudo /etc/init.d/ueyeusbdrc stop
   ```
   Alternatively, if you have a working graphical environment, the daemons may be controlled via the IDS Camera Manager (started as root)

2. Set camera ID
   
   To set the camera ID, you may use the IDS Camera Manager or the ueyesetid tool.
3. Set camera IP
   
   To set the camera persistent IP address, you may use the IDS Camera Manager or the ueyesetip tool.

### USB 3.1/USB 3/USB 2 uEye camera
After you installed the software, connect the camera to the PC, using the corresponding USB cable. The camera will be
recognized automatically. When you connect a camera with a PC or a new USB port for the first time, it is detected as
a new device and the firmware is uploaded to the camera. When the camera has been correctly installed, the LED on the
back of the camera lights up green and the camera is displayed in the list of the IDS Camera Manager.

#### USB 3/USB 3.1 uEye cameras under USB 2.0
USB 3/USB 3.1 uEye cameras are limited usable under USB 2.0. Depending on the camera model, not all camera functions are
available in USB 2.0 mode. USB 3/USB 3.1 uEye cameras are optimized for USB 3.0 ports and are not tested by
IDS Imaging Development Systems GmbH under USB 2.0.

Please note that due to the high performance of modern sensors, some USB 3/USB 3.1 uEye models are not supported in
USB 2.0 mode anymore, as the USB 2.0 interface does not provide enough power.

#### Multi-camera system with USB cameras/high resolution cameras

|                                                        |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
|:-------------------------------------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| A high CPU load may lead to USB transfer fails.        | Increase the daemon priority by reducing the "NICEVALUE" parameter in /lib/systemd/ueyeusbdrc.service or /etc/init.d/ueyeusbdrc. Note: If you make changes to the ueyeusbdrc.service file, you must run the following command before restarting the USB uEye daemon. ```$> sudo systemctl daemon-reload```                                                                                                                                                                                     |
| USB sub-system behavior (BulkTransferSize)             | With "Bulk Transfer Size" parameter, the behavior of the USB sub-system can be set. If you change the "Bulk transfer size" value, you have to analyze the effects of the change carefully. The "BulkTransferSize" parameter can be changed in the file /etc/ids/ueye/ueyeusbd.conf (default: 512 KB).                                                                                                                                                                                          |
| USB sub-system behavior (NumRequests)                  | The "NumRequests" parameter defines the number of requests to be preloaded. This parameter should also be changed if the "BulkTransferSize" parameter is changed (default: 6).                                                                                                                                                                                                                                                                                                                 |
| Buffer memory of the USB file system (usbfs_memory_mb) | The buffer memory's default value of the USB file system is often too low for a multi-camera system with USB cameras. Increase the memory value to avoid transfer losses. To adjust the memory value, you must change the "usbfs_memory_mb" parameter with root privileges:<br />Example: Increase the "usbfs_memory_mb" parameter to 256 MB:<br />```echo 'new size' > /sys/module/usbcore/parameters/usbfs_memory_mb```<br />```echo 256 > /sys/module/usbcore/parameters/usbfs_memory_mb``` |

### GigE uEye camera

After you installed the software, connect the camera with the network. Check the power supply to the camera. Use either
an external power supply or - depending on the model - via PoE (Power over Ethernet).

**NOTICE!** The camera should not be supplied through both voltage sources at once as this can irreparably damage the
camera.

Before you can use the camera on the network, you need to assign a valid IP address to the camera in the
IDS Camera Manager.

#### Note regarding GigE uEye cameras

By default, the installer configures the default ethernet network interfaces. If you use another network interface
to connect your cameras, insert the interface name at the interface configuration parameter in
"[Parameters]-Interfaces" of /etc/ids/ueye/ueyeethd.conf. You must be root to edit the configuration file.

The GigE uEye daemon network interfaces may be configured with the IDS Camera Manager if a graphical environment is
available.

**Note:** ueyeethd must be stopped **before** manually editing the configuration file!

## List of contained files and dependencies

See list on https://en.ids-imaging.com/open-source.html

## Uninstallation

### Uninstalling the debian packages

- To uninstall the packages, use

   ```$> sudo apt-get remove "ueye*"```

   This removes the packages but not the dependencies or the configuration files. \
   You can remove the "ueye" meta package from your system. Other installed packages such as "ueye-driver-usb" will still remain installed.
- To remove the packages and their dependencies, use:

   ```$> sudo apt-get autoremove "ueye*"```

### Uninstalling the archive

- To uninstall all, run as root:

   ```$> sudo /usr/bin/ueyesetup -u all```

- To uninstall GigE uEye variant, run as root:

   ```$> sudo /usr/bin/ueyesetup -u eth```

- To uninstall USB uEye variant, run as root:

   ```$> sudo /usr/bin/ueyesetup -u usb```


You should always use the setup script that came with the previous installation to ensure proper system cleanup. Do not attempt to remove the IDS Software Suite manually.

**Note:** The configuration files are not uninstalled and remain on the system.

## Known issues

This section lists known issues that might occur in this release.

|                                                                                                                            |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|:---------------------------------------------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Debian 10: USB and ETH daemons cannot be started after installation because no user/group was created during installation. | See also [New in Buster](https://wiki.debian.org/NewInBuster) <br />The su command in buster is provided by the util-linux source package, instead of the shadow source package, and no longer alters the PATH variable by default. This means that after doing su, your PATH may not contain directories like /sbin, and many system administration commands will fail. There are several workarounds:<ul><li>Use ```su -``` instead; this launches a login shell, which forces PATH to be changed, but also changes everything else including the working directory.</li><li>Use sudo instead. sudo still runs commands with an altered PATH variable.<ul><li>To get a regular root shell with the correct PATH, you may use sudo -s.</li><li>To get a login shell as root (equivalent to su -), you may use sudo -i.</li></ul><li>Put ALWAYS_SET_PATH yes in /etc/login.defs to get an approximation of the old behavior. This is documented in su but not in login.defs. It may also cause a harmless error message to appear in some situations.</li><li>Put the system administration directories (/sbin, /usr/sbin, /usr/local/sbin) in your regular account's PATH.</li></ul> |
| OpenGL usage                                                                                                               | The is_SetDisplayMode() function returns "IS_NO_SUCCESS". For using OpenGL the libgl1-mesa package is required. Check if the package and its dependencies are installed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Distributions that have no libomp.so.5                                                                                     | You have two possibilities<ul><li>Create a symlink from libomp.so.5 to libomp.so <br />`[user@pc]$ sudo ln -s /usr/lib64/libomp.so /usr/lib64/libomp.so.5` </li><li>Remove the version suffix from the library <br />`[user@pc]$ sudo patchelf --replace-needed libomp.so.5 libomp.so /opt/ids/ueye/lib/libueye_api.so`</li></ul>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| libomp issues on Linux Embedded (armhf)                                                                                    | There is an issue when you use libomp on a Embedded System (armhf) that may prevents compiling. This issue occurs when compiling and linking the API with a C file. Possible solutions are:<ul><li>Install libomp5-8</li><li>Install libffi-dev and link your program with -lffi</li></ul>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |

## Contact

IDS Imaging Development Systems GmbH \
Dimbacher Str. 10 \
D-74182 Obersulm/Germany

T: +49 7134 96196-0 \
E: info@ids-imaging.com \
W: https://en.ids-imaging.com

© IDS Imaging Development Systems GmbH, June 2022